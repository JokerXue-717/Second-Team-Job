// 云函数入口文件
const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

// 云函数入口函数
exports.main = async (event, context) => {
  const db = cloud.database();
  const postId = event.postId;
  const userId = event.userId;

  try {
    // 获取当前帖子
    const post = await db.collection('Posts').doc(postId).get();

    // 检查帖子是否是当前用户发布的
    if (post.data.userId !== userId) {
      return {
        success: false,
        message: '用户无权删除此帖子'
      };
    }

    // 删除帖子
    const res = await db.collection('Posts').doc(postId).remove();

    return {
      success: true,
      data: res
    };
  } catch (e) {
    return {
      success: false,
      error: e
    };
  }
};