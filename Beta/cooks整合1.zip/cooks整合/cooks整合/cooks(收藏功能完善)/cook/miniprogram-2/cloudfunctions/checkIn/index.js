const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

const db = cloud.database();

exports.main = async (event, context) => {
  const { userId } = event;

  // 添加日志输出，确保传递的参数 userId 是正确的
  console.log("Received userId:", userId);

  // 检查 userId 是否存在
  if (!userId) {
    return {
      success: false,
      message: '缺少 userId 参数'
    };
  }

  try {
    // 获取用户数据
    const userDoc = await db.collection('Users').doc(userId).get();
    
    // 检查用户是否存在
    if (!userDoc.data) {
      return {
        success: false,
        message: '用户不存在'
      };
    }

    // 获取签到历史和积分
    const { checkInHistory = [], points = 0 } = userDoc.data;

    // 获取当前日期，格式：YYYY-MM-DD
    const today = new Date().toISOString().split('T')[0];

    // 检查今天是否已经签到
    if (checkInHistory.includes(today)) {
      return {
        success: false,
        message: '今天已经签到过了'
      };
    }

    // 更新签到历史和积分
    checkInHistory.push(today);
    const newPoints = points + 10; // 每次签到加10积分

    // 更新数据库
    await db.collection('Users').doc(userId).update({
      data: {
        checkInHistory,
        points: newPoints
      }
    });

    // 返回成功的结果
    return {
      success: true,
      message: '签到成功',
      points: newPoints
    };
  } catch (err) {
    console.error('签到失败', err);
    return {
      success: false,
      message: '签到失败，请稍后再试'
    };
  }
};
