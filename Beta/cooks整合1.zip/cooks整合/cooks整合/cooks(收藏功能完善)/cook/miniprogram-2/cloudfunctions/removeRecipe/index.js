const cloud = require('wx-server-sdk')

cloud.init({
  env: 'cook-0gsfr85vbfb14582' // 替换为你的云开发环境 ID
})

exports.main = async (event, context) => {
  const db = cloud.database()
  const { recipeId } = event
  const { OPENID } = cloud.getWXContext() // 获取当前用户的 openid

  console.log('云函数初始化完成')
  console.log('接收到的参数:', event)
  console.log('当前用户 OPENID:', OPENID)

  if (!OPENID) {
    console.error('未获取到用户 OPENID')
    return {
      success: false,
      error: '未登录或用户信息丢失，请重新登录后再试'
    }
  }

  if (!recipeId || typeof recipeId !== 'string') {
    console.error('无效的菜谱 ID:', recipeId)
    return {
      success: false,
      error: '无效的菜谱 ID'
    }
  }

  try {
    // 1. 检查目标菜谱是否存在
    const recipe = await db.collection('Recipes').doc(recipeId).get()
    console.log('查询到的菜谱:', recipe)

    if (!recipe.data) {
      console.error('未找到菜谱:', recipeId)
      return {
        success: false,
        error: '未找到菜谱'
      }
    }

    // 2. 校验当前用户是否为菜谱的创建者
    if (recipe.data.ownerId !== OPENID) {
      console.error('用户无权限删除此菜谱:', recipeId)
      return {
        success: false,
        error: '无权限删除此菜谱'
      }
    }

    // 3. 删除目标菜谱
    const deleteResult = await db.collection('Recipes').doc(recipeId).remove()
    console.log('删除结果:', deleteResult)

    return {
      success: true,
      message: '菜谱删除成功'
    }
  } catch (err) {
    console.error('云函数执行错误:', err)

    // 根据错误类型返回更友好的提示
    if (err.errMsg && err.errMsg.includes('document.get:fail')) {
      return {
        success: false,
        error: '未找到对应的菜谱，请检查菜谱 ID 是否正确'
      }
    }

    return {
      success: false,
      error: err.message || '删除失败'
    }
  }
}
