const db = wx.cloud.database();

exports.main = async (event, context) => {
  const { userId, targetUserId } = event;

  try {
    // 获取用户数据
    const userRes = await db.collection('Users').where({ _id: userId }).get();
    const user = userRes.data[0];

    // 如果没有关注该用户，返回提示
    if (!user.follows.includes(targetUserId)) {
      return { success: false, message: "您尚未关注该用户。" };
    }

    // 移除目标用户ID
    const follows = user.follows.filter(id => id !== targetUserId);

    await db.collection('Users').doc(userId).update({
      data: { follows: follows }
    });

    return { success: true, message: "取关成功！" };

  } catch (error) {
    console.error(error);
    return { success: false, message: "取关失败，请稍后再试。" };
  }
};
