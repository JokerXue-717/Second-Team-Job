// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})
const db = cloud.database()

// 云函数入口函数
exports.main = async (event, context) => {
  try {
    const { id } = event
    console.log('接收到的id:', id)

    // 获取集合中的所有数据
    const result = await db.collection('CookingRecipeSteps').get()
    console.log('查询到的原始数据:', result.data)

    let recipeData = null
    
    // 遍历所有文档
    if (result.data && result.data.length > 0) {
      for (const doc of result.data) {
        if (doc.recipes && Array.isArray(doc.recipes)) {
          // 在recipes数组中查找匹配id的菜谱
          const recipe = doc.recipes.find(r => r.id === id || r.id === Number(id))
          if (recipe) {
            recipeData = recipe
            break
          }
        }
      }
    }

    console.log('找到的菜谱数据:', recipeData)

    return {
      success: true,
      data: recipeData ? [recipeData] : [],
      message: recipeData ? '获取成功' : '未找到相关菜谱',
      debug: {
        receivedId: id,
        idType: typeof id,
        documentsCount: result.data.length
      }
    }
  } catch (error) {
    console.error('云函数错误:', error)
    return {
      success: false,
      message: error.message,
      error: error
    }
  }
}