// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  const db = cloud.database()
  const { name, category, description, ingredients, steps, imageUrl } = event
  const { OPENID } = cloud.getWXContext() // 获取当前用户的 openid

  try {
    // 检查数据库中是否已有相同的记录
    const existing = await db.collection('Recipes').where({
      name,
      ownerId: OPENID // 同一用户
    }).get()

    if (existing.data.length > 0) {
      // 已存在相同的记录，返回错误提示
      console.log('重复记录:', existing.data)
      return { success: false, error: `食谱 "${name}" 已存在，请勿重复添加` }
    }

    // 插入新的食谱数据
    const res = await db.collection('Recipes').add({
      data: {
        name,
        category,
        description,
        ingredients,
        steps,
        imageUrl,
        ownerId: OPENID, // 当前用户
        createdAt: new Date(), // 创建时间
        updatedAt: new Date()  // 更新时间
      }
    })

    console.log('插入成功:', res)
    return { success: true, id: res._id } // 返回新增食谱的 ID
  } catch (e) {
    console.error('插入失败:', e) // 记录错误信息
    return { success: false, error: e }
  }
}
