// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

// 云函数入口函数
exports.main = async (event, context) => {
  try {
    const wxContext = cloud.getWXContext()
    const { recipeId, recipeData } = event

    console.log('收到的参数：', {
      recipeId,
      recipeData,
      openid: wxContext.OPENID
    })

    // 1. 查询用户收藏记录
    const collectRes = await db.collection('Collect_recipes')
      .where({
        _openid: wxContext.OPENID
      })
      .get()

    console.log('查询结果：', collectRes)

    // 2. 处理收藏逻辑
    if (collectRes.data.length === 0) {
      // 首次收藏，创建新记录
      const addResult = await db.collection('Collect_recipes').add({
        data: {
          _openid: wxContext.OPENID,
          data: [recipeData],
          createTime: db.serverDate()
        }
      })

      console.log('创建收藏记录：', addResult)

      return {
        success: true,
        status: 'collected',
        message: '收藏成功'
      }
    }

    // 已有收藏记录
    const userCollect = collectRes.data[0]
    const isCollected = userCollect.data && 
                       Array.isArray(userCollect.data) && 
                       userCollect.data.some(item => item.id === recipeId)

    console.log('当前收藏状态：', isCollected)

    if (isCollected) {
      // 取消收藏
      const newData = userCollect.data.filter(item => item.id !== recipeId)
      const updateResult = await db.collection('Collect_recipes')
        .doc(userCollect._id)
        .update({
          data: {
            data: newData,
            updateTime: db.serverDate()
          }
        })

      console.log('取消收藏结果：', updateResult)

      return {
        success: true,
        status: 'uncollected',
        message: '已取消收藏'
      }
    } else {
      // 添加收藏
      const newData = Array.isArray(userCollect.data) ? [...userCollect.data] : []
      newData.push(recipeData)

      const updateResult = await db.collection('Collect_recipes')
        .doc(userCollect._id)
        .update({
          data: {
            data: newData,
            updateTime: db.serverDate()
          }
        })

      console.log('添加收藏结果：', updateResult)

      return {
        success: true,
        status: 'collected',
        message: '收藏成功'
      }
    }
  } catch (error) {
    console.error('云函数执行错误：', error)
    return {
      success: false,
      error: error.message || '未知错误',
      message: '操作失败，请重试'
    }
  }
}