const db = wx.cloud.database();

exports.main = async (event, context) => {
  const { userId, targetUserId } = event;

  try {
    // 获取用户数据
    const userRes = await db.collection('Users').where({ _id: userId }).get();
    const user = userRes.data[0];

    // 如果已经关注，返回提示
    if (user.follows.includes(targetUserId)) {
      return { success: false, message: "您已经关注该用户。" };
    }

    // 更新用户的关注列表
    const follows = [...user.follows, targetUserId];

    await db.collection('Users').doc(userId).update({
      data: { follows: follows }
    });

    return { success: true, message: "关注成功！" };

  } catch (error) {
    console.error(error);
    return { success: false, message: "关注失败，请稍后再试。" };
  }
};
