const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

exports.main = async (event, context) => {
  const db = cloud.database()
  const { id } = event

  try {
    console.log('接收到的id:', id);

    // 获取CookingRecipeSteps集合中的数据
    const result = await db.collection('CookingRecipeSteps').get()
    console.log('查询结果：', result.data);

    if (result.data && result.data.length > 0) {
      console.log('找到的文档数量：', result.data.length);
      
      // 找到包含recipes的文档
      const doc = result.data.find(doc => doc.recipes && Array.isArray(doc.recipes))
      console.log('找到的文档：', doc);
      
      if (doc) {
        console.log('recipes数组：', doc.recipes);
        // 从recipes数组中找到对应id的菜谱
        const recipe = doc.recipes.find(item => item.id === id)
        console.log('找到的菜谱：', recipe);
        
        if (recipe) {
          return {
            success: true,
            data: recipe,
            allRecipes: doc.recipes
          }
        } else {
          return {
            success: false,
            error: `未找到id为${id}的菜谱`
          }
        }
      } else {
        return {
          success: false,
          error: '文档中没有recipes数组'
        }
      }
    }

    return {
      success: false,
      error: '集合为空'
    }

  } catch (error) {
    console.error('云函数执行错误：', error)
    return {
      success: false,
      error: error.message
    }
  }
}