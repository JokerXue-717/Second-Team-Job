// cloudfunctions/lookDiary/index.js
const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV // 使用当前云环境
});

const db = cloud.database();

// 云函数入口函数
exports.main = async (event, context) => {
  const { date } = event; // 获取传递的日期参数

  try {
    const result = await db.collection('Diaries')
      .where({
        date: date // 查询条件，日期匹配
      })
      .get();

    if (result.data.length > 0) {
      return {
        success: true,
        data: result.data[0] // 返回找到的第一个日记记录
      };
    } else {
      return {
        success: false,
        message: '未找到对应日期的日记'
      };
    }
  } catch (error) {
    return {
      success: false,
      message: error.message
    };
  }
};