const cloud = require('wx-server-sdk')

cloud.init({
  env: 'cook-0gsfr85vbfb14582' // 替换为你的云开发环境 ID
})

exports.main = async (event, context) => {
  const db = cloud.database()
  const { recipeId, updates } = event
  const { OPENID } = cloud.getWXContext() // 获取当前用户的 openid

  console.log('接收到的参数:', event)

  if (!OPENID) {
    console.error('未获取到用户 OPENID')
    return {
      success: false,
      error: '未登录或用户信息丢失，请重新登录后再试'
    }
  }

  if (!recipeId || typeof recipeId !== 'string') {
    console.error('无效的菜谱 ID:', recipeId)
    return {
      success: false,
      error: '无效的菜谱 ID'
    }
  }

  try {
    // 1. 检查目标菜谱是否存在
    console.log('开始查询菜谱...')
    const recipe = await db.collection('Recipes').doc(recipeId).get()
    console.log('查询到的菜谱:', recipe)

    if (!recipe.data) {
      console.error('未找到菜谱:', recipeId)
      return {
        success: false,
        error: '未找到菜谱'
      }
    }

    // 2. 校验当前用户是否为菜谱的创建者
    if (recipe.data.ownerId !== OPENID) {
      console.error('用户无权限修改此菜谱:', recipeId)
      return {
        success: false,
        error: '无权限修改此菜谱'
      }
    }

    // 3. 更新菜谱
    console.log('开始更新菜谱...')
    const updateResult = await db.collection('Recipes').doc(recipeId).update({
      data: {
        ...updates, // 合并更新的字段
        updatedAt: new Date() // 添加更新时间
      }
    })
    console.log('更新结果:', updateResult)

    return {
      success: true,
      message: '菜谱更新成功'
    }
  } catch (err) {
    console.error('云函数执行错误:', err)

    // 处理具体的错误类型
    if (err.errMsg && err.errMsg.includes('document.get:fail')) {
      return {
        success: false,
        error: '未找到对应的菜谱，请检查菜谱 ID 是否正确'
      }
    }

    return {
      success: false,
      error: err.message || '更新失败'
    }
  }
}
