const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV // 使用当前环境
})

const db = cloud.database()

// 主处理函数
exports.main = async (event, context) => {
  const { date, newContent, newImagePath } = event;

  try {
    // 删除旧的记录
    await db.collection('Diaries') // 假设你的集合名为 diaries
      .where({
        date: date // 根据日期查找记录
      })
      .remove();

    // 插入新的记录
    await db.collection('Diaries')
      .add({
        data: {
          date: date,
          content: newContent
        }
      });

    return {
      success: true,
      message: '日记已成功更新'
    };
  } catch (err) {
    return {
      success: false,
      message: err.message
    };
  }
}