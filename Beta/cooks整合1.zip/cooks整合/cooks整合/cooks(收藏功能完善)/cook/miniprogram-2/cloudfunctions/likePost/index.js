// 云函数入口文件
const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

// 云函数入口函数
exports.main = async (event, context) => {
  const db = cloud.database();
  const _ = db.command;
  const postId = event.postId;
  const userId = event.userId;

  try {
    // 获取当前帖子
    const post = await db.collection('Posts').doc(postId).get();
    
    // 检查用户是否已经点赞过
    if (post.data.likedBy && post.data.likedBy.includes(userId)) {
      return {
        success: false,
        message: '用户已经点赞过'
      };
    }

    // 更新帖子，增加点赞数并记录用户
    const res = await db.collection('Posts').doc(postId).update({
      data: {
        likes: _.inc(1),
        likedBy: _.push(userId)
      }
    });

    return {
      success: true,
      data: res
    };
  } catch (e) {
    return {
      success: false,
      error: e
    };
  }
};