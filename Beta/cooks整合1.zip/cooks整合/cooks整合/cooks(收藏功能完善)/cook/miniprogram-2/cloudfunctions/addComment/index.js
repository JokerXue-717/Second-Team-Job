// 云函数入口文件
const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

// 云函数入口函数
exports.main = async (event, context) => {
  const db = cloud.database();
  const _ = db.command;
  const postId = event.postId;
  const userId = event.userId;
  const comment = event.comment;

  try {
    // 更新帖子，添加评论
    const res = await db.collection('Posts').doc(postId).update({
      data: {
        comments: _.push({
          userId: userId,
          comment: comment,
          timestamp: new Date()
        })
      }
    });

    return {
      success: true,
      data: res
    };
  } catch (e) {
    return {
      success: false,
      error: e
    };
  }
};