// cloudfunctions/deleteRecipe/index.js
const cloud = require('wx-server-sdk')

cloud.init({
  env: 'cook-0gsfr85vbfb14582'
})

exports.main = async (event, context) => {
  const db = cloud.database()
  const _ = db.command
  const { recipeId } = event

  console.log('要删除的菜谱ID:', recipeId)

  try {
    // 1. 获取当前收藏文档
    const result = await db.collection('Collect_recipes')
      .orderBy('id', 'asc')
      .limit(1)
      .get()

    if (!result.data || !result.data.length) {
      console.error('未找到收藏数据')
      return {
        success: false,
        error: '未找到收藏数据'
      }
    }

    const docId = result.data[0]._id
    const currentData = result.data[0].data || []
    
    console.log('当前数据:', currentData)

    // 2. 检查要删除的菜谱是否存在
    const targetRecipe = currentData.find(recipe => recipe.id.toString() === recipeId)
    if (!targetRecipe) {
      console.error('未找到要删除的菜谱:', recipeId)
      return {
        success: false,
        error: '未找到要删除的菜谱'
      }
    }

    // 3. 创建新的数组，排除要删除的菜谱
    const newData = currentData.filter(recipe => {
      const keep = recipe.id.toString() !== recipeId
      console.log(`检查菜谱 ${recipe.id}: ${keep ? '保留' : '删除'}`)
      return keep
    })

    console.log('更新后的数据:', newData)

    // 4. 更新数据库
    const updateResult = await db.collection('Collect_recipes')
      .doc(docId)
      .update({
        data: {
          data: newData
        }
      })

    console.log('数据库更新结果:', updateResult)

    // 5. 验证更新是否成功
    const verifyResult = await db.collection('Collect_recipes')
      .doc(docId)
      .get()

    const updatedData = verifyResult.data.data
    console.log('验证后的数据:', updatedData)

    return {
      success: true,
      data: updatedData
    }

  } catch (err) {
    console.error('云函数执行错误:', err)
    return {
      success: false,
      error: err.message || '删除失败'
    }
  }
}