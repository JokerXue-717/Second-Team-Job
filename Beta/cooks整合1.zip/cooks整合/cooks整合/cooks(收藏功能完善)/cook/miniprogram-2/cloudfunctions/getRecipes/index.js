// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  const db = cloud.database() // 初始化数据库
  const { category, name } = event // 获取前端传递的参数

  // 校验参数
  if (!category && !name) {
    return { success: false, error: '参数 category 或 name 至少需要一个' }
  }

  // 构建查询条件
  let query = {}
  if (category) {
    query.category = category
  }
  if (name) {
    query.name = name
  }

  try {
    // 查询 Recipes 集合
    const recipes = await db.collection('Recipes')
                            .where(query) // 按条件查询
                            .limit(20)    // 限制返回条数
                            .get()
    return { success: true, data: recipes.data }
  } catch (e) {
    console.error('查询失败:', e)
    return { success: false, error: e }
  }
}
