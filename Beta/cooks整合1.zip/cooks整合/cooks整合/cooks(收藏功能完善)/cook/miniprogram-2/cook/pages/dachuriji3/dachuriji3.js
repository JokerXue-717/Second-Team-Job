Page({
  data: {
    selectedDate: '', // 初始化选中的日期为空字符串
    diaryContent: '', // 存储日记内容
    diaryImage: '' // 存储日记图片路径
  },

  onLoad: function(options) {
    if (options.date) {
      this.setData({
        selectedDate: options.date
      });

      // 调用云函数获取日记内容
      this.getDiaryByDate(options.date);
    }
  },

  getDiaryByDate: async function(date) {
    try {
      const result = await wx.cloud.callFunction({
        name: 'lookDiary', // 云函数名
        data: {
          date: date
        }
      });

      if (result.result.success) {
        const diaryData = result.result.data;
        this.setData({
          diaryContent: diaryData.content,
          diaryImage: diaryData.imagePath
        });
      } else {
        wx.showToast({
          title: result.result.message,
          icon: 'none',
          duration: 2000
        });
      }
    } catch (error) {
      wx.showToast({
        title: '调用失败，请检查网络',
        icon: 'none',
        duration: 2000
      });
    }
  },

  // 处理日记内容输入变化的方法
  handleContentInput: function(event) {
    this.setData({
      diaryContent: event.detail.value
    });
  },

  // 添加更新日记的方法
  updateDiary: async function() {
    const { selectedDate, diaryContent, diaryImage } = this.data;

    try {
      const result = await wx.cloud.callFunction({
        name: 'changeDiary', // 新的云函数名
        data: {
          date: selectedDate,
          newContent: diaryContent,
          newImagePath: diaryImage
        }
      });

      if (result.result.success) {
        return true;
      } else {
        wx.showToast({
          title: result.result.message,
          icon: 'none',
          duration: 2000
        });
        return false;
      }
    } catch (error) {
      wx.showToast({
        title: '调用失败，请检查网络',
        icon: 'none',
        duration: 2000
      });
      return false;
    }
  },

  // 保存日记的方法
  saveDiary: async function() {
    const isUpdated = await this.updateDiary();
    if (isUpdated) {
      wx.showToast({
        title: '日记已成功更新',
        icon: 'success',
        duration: 2000
      });
      setTimeout(() => {
        wx.navigateBack(); // 返回上一个页面
      }, 2000);
    }
  }
});