// pages/diary/diary.js
Page({
  data: {
    diaryText: '', // 存储日记文本
    selectedDate: '' // 初始化选中的日期为空字符串
  },
  
  onInput: function(e) {
    this.setData({
      diaryText: e.detail.value // 更新日记文本
    });
  },

  saveDiary: function() {
    const diaryText = this.data.diaryText.trim();
    const selectedDate = this.data.selectedDate;
    if (diaryText) {
      // 调用云函数保存日记
      wx.cloud.callFunction({
        name: 'addDiary', // 云函数名
        data: {
          diaryText: diaryText,
          date: selectedDate
        },
        success: res => {
          if (res.result.success) {
            wx.showToast({
              title: '日记保存成功',
              icon: 'success',
              duration: 2000
            });
            setTimeout(() => {
              wx.navigateBack({
                delta: 1
              });
            }, 2000);
          } else {
            wx.showToast({
              title: '保存失败',
              icon: 'none',
              duration: 2000
            });
          }
        },
        fail: err => {
          wx.showToast({
            title: '调用失败，请检查网络',
            icon: 'none',
            duration: 2000
          });
        }
      });
    } else {
      wx.showToast({
        title: '日记内容不能为空',
        icon: 'none',
        duration: 2000
      });
    }
  },

  onLoad: function(options) {
    // 获取当前日期并设置为默认选中的日期
    const now = new Date();
    const year = now.getFullYear();
    const month = ('0' + (now.getMonth() + 1)).slice(-2);
    const day = ('0' + now.getDate()).slice(-2);
    const currentDate = `${year}-${month}-${day}`;

    this.setData({
      selectedDate: currentDate
    });
  }
});