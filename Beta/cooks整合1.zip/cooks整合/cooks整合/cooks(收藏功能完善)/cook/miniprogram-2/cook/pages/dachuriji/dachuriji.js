 // pages/dachuriji/dachuriji.js
Page({
  data: {
      signText: '签到', // 签到按钮的文本
      selectedDate: '', // 默认选中的日期
      continuousSignDays: 1, // 连续签到天数
      totalSignDays: 2 // 累计签到天数
  },
    // 页面加载时执行
    onLoad: function () {
      // 获取当前日期
      const now = new Date();
      const year = now.getFullYear();
      const month = ('0' + (now.getMonth() + 1)).slice(-2);
      const day = ('0' + now.getDate()).slice(-2);
      const currentDate = `${year}-${month}-${day}`;
  
      // 设置当前日期为默认选中的日期
      this.setData({
        selectedDate: currentDate
      });
    },
  onDateChange: function(e) {
      this.setData({
          selectedDate: e.detail.value
      });
  },
  toggleSignStatus: function() {
      // 切换签到状态
      this.setData({
          signText: this.data.signText === '签到' ? '已签到' : '签到'
      });
      // 这里可以添加签到的逻辑
      console.log('签到状态已切换');
  },
  yes: function() {
    const { selectedDate } = this.data;
    wx.navigateTo({
      url: `../dachuriji3/dachuriji3?date=${selectedDate}`
    });
  },
  onAdd: function() {
    wx.navigateTo({
      url: `../dachuriji2/dachuriji2`
    });
  }
});