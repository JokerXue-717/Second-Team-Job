Page({
  data: {
    avatarUrl: '', 
    nickname: '', 
    introduction: '', 
    collections: 0, 
    following: 0, 
    posts: 0, 
    points: 0,
    hasUserInfo: false
  },

  onLoad: function() {
    this.getCollectCount(); // 获取收藏数量
  },

  // 获取收藏数量
  getCollectCount: function() {
    const db = wx.cloud.database();
    
    db.collection('Collect_recipes')
      .get()
      .then(res => {
        console.log('收藏数据:', res.data);
        let collectCount = 0;
        
        // 遍历文档，获取data数组的长度
        if (res.data && res.data.length > 0 && res.data[0].data) {
          collectCount = res.data[0].data.length;
        }
        
        console.log('收藏的菜谱数量:', collectCount);
        
        this.setData({
          collections: collectCount
        });
      })
      .catch(err => {
        console.error('查询收藏失败:', err);
        wx.showToast({
          title: '获取收藏数量失败',
          icon: 'none'
        });
      });
  },

  // 获取用户信息按钮点击事件
  getUserProfile: function() {
    wx.getUserProfile({
      desc: '用于完善用户资料',
      success: res => {
        const userInfo = res.userInfo;
        this.setData({
          avatarUrl: userInfo.avatarUrl,
          nickname: userInfo.nickName,
          introduction: '这个人很懒，还没有介绍~',
          following: 0,
          posts: 0,
          points: 0,
          hasUserInfo: true
        });
      },
      fail: err => {
        console.error('获取用户信息失败:', err);
        wx.showToast({
          title: '获取用户信息失败',
          icon: 'none'
        });
      }
    });
  },

  logout: function() {
    this.setData({
      avatarUrl: '',
      nickname: '',
      introduction: '',
      following: 0,
      posts: 0,
      points: 0,
      hasUserInfo: false
    });
    wx.removeStorageSync('userToken');
    wx.showToast({
      title: '已退出登录',
      icon: 'success'
    });
  }
});