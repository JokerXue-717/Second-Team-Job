// pages/recipe_collection/recipe_collection.js
const app = getApp()

Page({
  data: {
    recipes: []
  },

  onLoad() {
    this.getRecipesData()
  },

  async getRecipesData() {
    try {
      const db = wx.cloud.database({
        env: 'cook-0gsfr85vbfb14582'
      })
      console.log('开始获取菜谱数据...')
      
      const result = await db.collection('Collect_recipes')
        .orderBy('id', 'asc')
        .limit(1)
        .get()
      
      if (result.data && result.data.length > 0 && result.data[0].data) {
        const recipesData = result.data[0].data
        this.setData({
          recipes: recipesData
        })
        console.log(`成功获取到 ${recipesData.length} 条菜谱数据`)
      } else {
        console.log('没有查询到数据')
        wx.showToast({
          title: '暂无菜谱数据',
          icon: 'none'
        })
      }
    } catch(err) {
      console.error('获取菜谱数据失败：', err)
      wx.showToast({
        title: '获取数据失败',
        icon: 'error'
      })
    }
  },

  async deleteRecipe(e) {
    const recipeId = e.currentTarget.dataset.recipeId
    console.log('要删除的菜谱ID:', recipeId, '当前数据:', this.data.recipes)
    
    if (!recipeId) {
      wx.showToast({
        title: '菜谱ID无效',
        icon: 'error'
      })
      return
    }

    try {
      const res = await wx.showModal({
        title: '确认删除',
        content: '确定要删除这个菜谱吗？',
        confirmText: '删除',
        confirmColor: '#07c160'
      })
      
      if (!res.confirm) return

      wx.showLoading({
        title: '删除中...',
        mask: true
      })

      // 调用云函数删除菜谱
      const result = await wx.cloud.callFunction({
        name: 'deleteRecipe',
        data: { recipeId: recipeId.toString() }
      })

      console.log('云函数返回结果:', result)

      if (!result.result || !result.result.success) {
        throw new Error(result.result?.error || '删除失败')
      }

      const newData = result.result.data
      if (!Array.isArray(newData)) {
        throw new Error('返回数据格式错误')
      }

      this.setData({
        recipes: newData
      }, () => {
        wx.hideLoading()
        wx.showToast({
          title: '删除成功',
          icon: 'success'
        })
      })
      
    } catch (err) {
      wx.hideLoading()
      console.error('删除失败，详细错误：', err)
      wx.showToast({
        title: err.message || '删除失败',
        icon: 'error'
      })
      await this.getRecipesData()
    }
  },

  // 跳转到菜谱详情页
  goToDetail(e) {
    const recipeId = e.currentTarget.dataset.recipeId
    wx.navigateTo({
      url: `/pages/recipe_detail/recipe_detail?id=${recipeId}`
    })
  },

  // 跳转到作者主页
  goToAuthor(e) {
    const authorId = e.currentTarget.dataset.authorId
    wx.navigateTo({
      url: `/pages/author_home/author_home?id=${authorId}`
    })
  },

  // 下拉刷新
  async onPullDownRefresh() {
    try {
      await this.getRecipesData()
    } catch (err) {
      console.error('刷新失败：', err)
    } finally {
      wx.stopPullDownRefresh()
    }
  },

  // 分享
  onShareAppMessage() {
    return {
      title: '我的菜谱收藏',
      path: '/pages/recipe_collection/recipe_collection'
    }
  }
})