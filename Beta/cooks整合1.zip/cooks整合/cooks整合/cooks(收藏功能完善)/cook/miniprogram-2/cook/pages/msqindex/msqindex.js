const db = wx.cloud.database()
const MAX_LIMIT = 20 // 设置每次查询的最大数量

Page({
  data: {
    posts: [],
    userCollections: null,
    openid: ''
  },

  onLoad: async function() {
    console.log('页面开始加载')
    await this.getOpenid() // 等待获取openid完成
    this.getRecipeList()
    this.getUserCollections()
  },

  onShow: function() {
    if (this.data.openid) {
      this.getRecipeList()
    }
  },

  // 获取openid
  getOpenid: async function() {
    try {
      // 先尝试从缓存获取
      let openid = wx.getStorageSync('openid')
      
      if (!openid) {
        // 如果缓存中没有，则调用云函数获取
        const res = await wx.cloud.callFunction({
          name: 'login'
        })
        console.log('获取openid结果：', res)
        openid = res.result.openid
        // 存入缓存
        wx.setStorageSync('openid', openid)
      }

      console.log('当前openid：', openid)
      this.setData({ openid })
      return openid
    } catch (err) {
      console.error('获取openid失败：', err)
      wx.showToast({
        title: '登录失败，请重试',
        icon: 'none'
      })
    }
  },

  // 获取菜谱列表
  getRecipeList: async function() {
    try {
      const res = await db.collection('save_recipes')
        .limit(MAX_LIMIT)
        .orderBy('createTime', 'desc')
        .get()
      
      console.log('获取数据成功：', res)
      
      if (res.data && res.data[0] && res.data[0].data) {
        const recipesData = res.data[0].data
        console.log('菜谱数据：', recipesData)
        
        const formattedPosts = recipesData.map(item => ({
          id: item.id || item._id,
          imageUrl: item.imageUrl || item.fileIDs[0],
          title: item.name,
          description: item.name,
          authorName: item.authorName || item.nickName,
          authorAvatar: item.authorAvatar || item.avatarUrl,
          isCollected: false,
          // 添加其他需要的字段
          ingredients: item.ingredients || [],
          steps: item.steps || [],
          createTime: item.createTime || new Date(),
          updateTime: item.updateTime || new Date()
        }))
        
        console.log('格式化后的数据：', formattedPosts)
        
        this.setData({
          posts: formattedPosts
        }, () => {
          if (this.data.openid) {
            this.checkCollectionStatus()
          }
        })
      } else {
        throw new Error('数据格式不正确')
      }
    } catch (err) {
      console.error('获取数据失败：', err)
      wx.showToast({
        title: '获取数据失败',
        icon: 'none'
      })
    }
  },

  // 获取用户收藏记录
  getUserCollections: async function() {
    if (!this.data.openid) {
      console.log('未获取到openid，跳过获取收藏')
      return
    }
    
    try {
      const res = await db.collection('Collect_recipes')
        .where({
          _openid: this.data.openid
        })
        .limit(1)
        .get()
      
      console.log('获取收藏记录：', res)
      
      if (res.data.length > 0) {
        this.setData({
          userCollections: res.data[0]
        })
        this.checkCollectionStatus()
      }
    } catch (err) {
      console.error('获取用户收藏失败：', err)
      wx.showToast({
        title: '获取收藏记录失败',
        icon: 'none'
      })
    }
  },

  // 检查收藏状态
  checkCollectionStatus: function() {
    const { posts, userCollections } = this.data
    if (userCollections && userCollections.data && Array.isArray(userCollections.data)) {
      const updatedPosts = posts.map(post => ({
        ...post,
        isCollected: userCollections.data.some(item => 
          item.id === post.id || item.id === post.id.toString()
        )
      }))
      this.setData({
        posts: updatedPosts
      })
    }
  },

  // 处理收藏/取消收藏
  handleCollect: function(e) {
    if (!this.data.openid) {
      wx.showToast({
        title: '登录状态异常，请重试',
        icon: 'none'
      })
      return
    }

    const recipeId = e.currentTarget.dataset.recipeId
    if (!recipeId) {
      wx.showToast({
        title: '操作失败',
        icon: 'error'
      })
      return
    }

    const currentPost = this.data.posts.find(post => post.id === recipeId)
    if (!currentPost) {
      wx.showToast({
        title: '菜谱数据不存在',
        icon: 'error'
      })
      return
    }
    
    wx.showLoading({
      title: '处理中...',
    })
    
    wx.cloud.callFunction({
      name: 'toggleCollect',
      data: {
        recipeId: recipeId,
        recipeData: {
          id: currentPost.id,
          imageUrl: currentPost.imageUrl,
          title: currentPost.title,
          description: currentPost.description,
          authorName: currentPost.authorName,
          authorAvatar: currentPost.authorAvatar,
          // 添加其他需要的字段
          ingredients: currentPost.ingredients,
          steps: currentPost.steps,
          createTime: currentPost.createTime,
          updateTime: currentPost.updateTime
        }
      }
    }).then(res => {
      wx.hideLoading()
      console.log('收藏操作结果：', res)
      
      if (res.result && res.result.success) {
        // 更新本地状态
        const posts = [...this.data.posts]
        const postIndex = posts.findIndex(post => post.id === recipeId)
        if (postIndex !== -1) {
          posts[postIndex].isCollected = (res.result.status === 'collected')
          this.setData({ posts })
        }

        wx.showToast({
          title: res.result.message,
          icon: res.result.status === 'collected' ? 'success' : 'none'
        })
        
        // 刷新收藏状态
        this.getUserCollections()
      } else {
        console.error('收藏失败：', res.result)
        wx.showToast({
          title: res.result.message || '操作失败',
          icon: 'error'
        })
      }
    }).catch(err => {
      wx.hideLoading()
      console.error('收藏操作失败：', err)
      wx.showToast({
        title: '操作失败',
        icon: 'error'
      })
    })
  },

  // 点击图片进入详情页
  navigateToDetail: function(event) {
    const postId = event.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/detail/detail?id=${postId}`
    });
  },

  // 点击加号进入发布页
  navigateToPublish: function() {
    wx.navigateTo({
      url: '/pages/publish/publish'
    });
  },

  // 下拉刷新
  onPullDownRefresh: async function() {
    try {
      await this.getRecipeList()
      await this.getUserCollections()
      wx.stopPullDownRefresh()
    } catch (err) {
      console.error('刷新失败：', err)
      wx.stopPullDownRefresh()
    }
  },

  // 分享
  onShareAppMessage: function() {
    return {
      title: '美食菜谱',
      path: '/pages/msqindex/msqindex'
    }
  }
});