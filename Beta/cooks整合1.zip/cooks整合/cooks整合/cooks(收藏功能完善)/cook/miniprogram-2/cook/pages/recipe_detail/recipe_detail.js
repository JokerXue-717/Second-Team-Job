// pages/recipe_detail/recipe_detail.js
Page({
  data: {
    recipeData: {},
    recipeSteps: []
  },

  onLoad(options) {
    console.log('接收到的参数:', options)
    if (options.id) {
      this.getRecipeSteps(options.id)
    }
  },

  getRecipeSteps: function(id) {
    wx.showLoading({
      title: '加载中...',
    })
  
    wx.cloud.callFunction({
      name: 'getRecipeDetail_data',
      data: {
        id: id
      }
    }).then(res => {
      wx.hideLoading()
      console.log('完整的返回数据:', res)
      
      if (res.result && res.result.data && res.result.data.length > 0) {
        const recipeData = res.result.data[0]
        console.log('处理后的数据:', recipeData)
  
        // 处理步骤数据
        let steps = []
        if (Array.isArray(recipeData.steps)) {
          steps = recipeData.steps
        } else if (typeof recipeData.steps === 'string') {
          // 如果steps是字符串，尝试解析它
          try {
            steps = JSON.parse(recipeData.steps)
          } catch (e) {
            // 如果不是JSON格式，按照换行符分割
            steps = recipeData.steps.split('\n').filter(step => step.trim())
          }
        }
  
        this.setData({
          recipeSteps: steps,
          recipeData: {
            name: recipeData.title || '菜品名称',
            imageUrl: recipeData.imageUrl || '',
            description: recipeData.description || '',
            ingredients: recipeData.ingredients || '',
            steps: recipeData.steps // 保存原始steps数据
          }
        })
      } else {
        wx.showToast({
          title: '未找到相关数据',
          icon: 'none'
        })
      }
    }).catch(err => {
      wx.hideLoading()
      console.error('调用云函数失败：', err)
      wx.showToast({
        title: '获取数据失败',
        icon: 'none'
      })
    })
  },

  
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  // 返回上一页
  goBack: function() {
    wx.navigateBack()
  },

  // 跳转到更多评价页面
  navigateToMoreReviews: function() {
    wx.navigateTo({
      url: '/pages/reviews/reviews'
    })
  },

  // 处理图片加载失败
  handleImageError: function() {
    this.setData({
      'recipeData.imageUrl': '/images/default_recipe.png' // 设置一个默认图片路径
    })
  },

  // 预览图片
  previewImage: function() {
    if (this.data.recipeData.imageUrl) {
      wx.previewImage({
        urls: [this.data.recipeData.imageUrl]
      })
    }
  }
})