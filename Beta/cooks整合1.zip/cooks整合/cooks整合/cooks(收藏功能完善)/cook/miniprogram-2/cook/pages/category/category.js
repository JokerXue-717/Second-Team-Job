Page({
  data: {
    category: '',
    recipes: [] // 存储该分类下的菜品数据
  },

  onLoad: function (options) {
    const category = options.category; // 获取传递的分类参数
    console.log("Category received:", category); // 调试信息
    this.setData({ category });

    this.loadRecipes(category); // 加载对应的菜品数据
  },

  loadRecipes: function (category) {
    wx.cloud.callFunction({
      name: 'getRecipes', // 云函数名称
      data: { name: category }, // 按 name 搜索
      success: res => {
        console.log("Cloud function response:", res); // 调试信息
        if (res.result && res.result.success) {
          this.setData({ recipes: res.result.data }); // 直接存储完整数据
        } else {
          wx.showToast({
            title: '加载菜品失败',
            icon: 'none'
          });
        }
      },
      fail: err => {
        console.error("Cloud function error:", err); // 调试信息
        wx.showToast({
          title: '云函数调用失败',
          icon: 'none'
        });
      }
    });
  }
});
