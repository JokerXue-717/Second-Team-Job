const db = wx.cloud.database()

Page({
  data: {
    recipes: [], // 存储菜谱列表
    detail: {}, // 存储详情
    comments: [
      { user: '小明', text: '这个菜好好吃！' },
      { user: '小红', text: '我也想试试这个做法。' },
      { user: '小李', text: '做的不错，改天再试试。' }
    ]
  },

  onLoad: function(options) {
    console.log('接收到的id:', options.id);
    if (options.id) {
      this.loadRecipeDetail(options.id);
    }
  },

  // 加载菜谱详情
  async loadRecipeDetail(id) {
    try {
      console.log('正在查询CookingRecipeSteps, id:', Number(id));
      
      // 使用云函数获取数据
      const result = await wx.cloud.callFunction({
        name: 'getCookingRecipeSteps',
        data: {
          id: Number(id)
        }
      });

      console.log('云函数返回结果：', result);

      if (result.result && result.result.success) {
        const recipeData = result.result.data;
        console.log('找到的菜谱数据：', recipeData);

        // 设置详情数据
        this.setData({
          detail: recipeData
        });

        // 加载相关推荐
        if (result.result.allRecipes) {
          this.loadRelatedRecipes(result.result.allRecipes, id);
        }
      } else {
        console.error('未找到菜谱数据:', result.result?.error);
        wx.showToast({
          title: result.result?.error || '未找到菜谱',
          icon: 'error'
        });
      }

    } catch (error) {
      console.error('获取详情失败：', error);
      wx.showToast({
        title: '获取详情失败',
        icon: 'error'
      });
    }
  },

  // 加载相关推荐
  loadRelatedRecipes(allRecipes, currentId) {
    // 过滤掉当前菜谱，并最多显示4个推荐
    const relatedRecipes = allRecipes
      .filter(recipe => recipe.id !== Number(currentId))
      .slice(0, 4);

    this.setData({
      recipes: relatedRecipes
    });
  },

  // 跳转到评论页面
  goToReviews: function() {
    const postId = this.data.detail.id;
    wx.navigateTo({
      url: `/pages/user_reviews/user_reviews?id=${postId}`
    });
  },

  // 点击菜谱跳转到详情
  goToDetail: function(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/detail/detail?id=${id}`
    });
  },

  // 下拉刷新
  onPullDownRefresh: async function() {
    try {
      const currentId = this.data.detail.id;
      if (currentId) {
        await this.loadRecipeDetail(currentId);
      }
      wx.stopPullDownRefresh();
    } catch (err) {
      console.error('刷新失败：', err);
      wx.stopPullDownRefresh();
    }
  },

  // 分享
  onShareAppMessage: function() {
    const detail = this.data.detail;
    return {
      title: detail.title || '美味菜谱',
      path: `/pages/detail/detail?id=${detail.id}`,
      imageUrl: detail.imageUrl
    }
  }
});